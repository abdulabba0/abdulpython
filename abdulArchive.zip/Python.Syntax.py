""""
Syntax is how a language is strucured

"""

#variablename - assignment operator - value
a = 65

# # To display in python we use print
# print("Hello World!")

# # The if statement
# if a < 100 :
#     print ("a is less than 100")
#     print("I'm done")

# # block of code are created using :
# for x in range(10) :
#     if x % 2 == 0 : 
#         print(x)
# a = 0 

# while a < 10 :
#     print(a)
#     a += 1

def calmean(a):
        print(sum(a) / len(a))

calmean([4, 5, 6, 7]) 

# we use ash  to comment in python

#     print("""
# This is a multiline comment
# """)