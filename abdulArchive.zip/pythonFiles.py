"""
we use the open methos to work with file
"a" Creates or append
"w" Creates or rewrites
"r" read
"x" Creates a new file only
/n for line breaks
"t" Text - Default value. Text mode
"b" Binary - Binary mode (e.g images)
"""
# Creating a file
# file = open("index.txt", "a")
# file.write("Today is Great")
# file.close()


# file = open("index.txt", "w") # Creates a new file or rewrites the file if in existence
# file.write("I am Great")
# file.close()

# # Reading a file
# file = open("index.txt", "r")
# print(file.read()) # Read entire file
# print(file.read(10)) # Read characters file
# print(file.readlines(2)) # Read line file
# file.close()

# for line in file.readlines() :
#     print(line.strip())

# file = open("python.data_type.py", "r")
# print(file.read()) 
# file.close

# file = open("python.jpg", "rb")
# print(file.read()) 
# file.close

# file = open("python.jpg", "rb")
# filecontent = file.read(30)

# new_file = open("python.jpg", "wb")
# new_file.write() 
# file.close

