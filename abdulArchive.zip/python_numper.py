""" 
Number Type

75 : int
4.5 : float
6j : complex
"""

a = 75 #: int
b = 4.5 #: float
c = 6j #: complex

#checking the type
print(type(a))
print(type(b))
print(type(c))

""" 
intergers are whole number positive or negative
it has unlimited length

"""

a = 1
b = -4
c = 4444444444444444446666666666

print(a)
print(b)
print(c)

""" 
Float are number with decimal point, it
can also be scientific number

"""

a = 2.3
b = 3.3333333333333333333333333
c = -2.2
d = .2
e = -.2
f = -.2e4

print(a)
print(b)
print(c)
print(d)
print(e)
print(f)

""" 
Float are number with decimal point, it
can also be scientific number

"""

a = 5j
b = 4

print(a + b)

