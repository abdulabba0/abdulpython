import random

# print(random.random()) # generate random numbers

print(dir(random))